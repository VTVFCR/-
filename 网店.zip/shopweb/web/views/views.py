from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def vite_client_placeholder(request):
    return HttpResponse("// Vite client placeholder to avoid 404s", content_type="application/javascript")
