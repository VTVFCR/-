from django.shortcuts import render,redirect
from myadmin.models import User
from django.urls import reverse
#显示登录页面
def ulogin(request):
    return render(request,"web/login/login.html")
#执行登录
def udologin(request):
    try:
        user = User.objects.get(username = request.POST.get("username"))
        p = request.POST.get("password")
        if p == user.password:
            print("登陆成功")
            request.session["webuser"] = user.toDict()
            # 初始化收藏数量到session
            from myadmin.models import favorite, Order
            request.session['favorite_count'] = favorite.objects.filter(users__id=user.id).count()
            # 初始化购物车数量到session
            request.session['cart_count'] = Order.objects.filter(orderuser=user.username).count()
            return redirect(reverse("web_index"))
        else:
            context={"info":"密码错误"}
    except Exception as err:
        print(err)
        context = {"info":"账号错误"}
    return render(request,"web/login/login.html",context)
#显示注册页面
def uregister(request):
    return render(request,"web/login/register.html")
#执行注册
def udoregister(request):
    try:
        user = User()
        user.username = request.POST.get("username")
        user.password = request.POST.get("password")
        gender = request.POST.get("gender")
        if gender == "男":
            user.gender = 'M'
        elif gender == "女":
            user.gender = 'F'
        else:
            user.gender= None
        user.birthday = request.POST.get("birthday")
        context = {"info":"注册成功"}
        user.save()
    except Exception as err:
        print(err)
        context = {"info":"注册失败"}
    return render(request,"web/login/info.html",context)
#执行退出登录
def ulogout(request):
    del request.session['webuser']
    return redirect(reverse("web_login"))
#显示个人页面
def personal(request):
    if "webuser" in request.session:
        try:
            current_webuser = request.session['webuser']['username']
            ob = User.objects.filter(username=current_webuser).first()
            context = {"ob": ob}
            return render(request, "web/login/personal.html", context)
        except Exception as err:
            print(err)
            context = {"info": "无法显示"}
            return render(request, "web/login/personal.html", context)
    else:
        return render(request, "web/login/personal.html", {"info": "请先登录"})

#执行编辑个人页面
def epersonal(request,uid=0):
    try:
        ob = User.objects.get(id = uid)
        ob.username = request.POST.get("username")
        gender = request.POST.get("gender")
        if gender=="男":
            ob.gender = 'M'
        elif gender == "女":
            ob.gender = 'F'
        else:
            ob.gender = None
        ob.save()
        context = {"info":"编辑成功"}
    except Exception as err:
        print(err)
        context = {"info":"编辑失败"}
        return redirect(reverse("web_personal"),context) 
#显示首页
def index(request):
    return render(request,"web/login/index.html")