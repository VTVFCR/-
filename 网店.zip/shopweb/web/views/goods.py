
from django.shortcuts import redirect, render
from myadmin import models
from myadmin.models import Goods,Order,User,favorite
from django.urls import reverse
from django.db.models import Max

#显示商品列表
def list(request,uid):
    try:
        # 获取搜索关键词
        keyword = request.GET.get('keyword', '').strip()
        
        # 基础查询 - 按类型筛选
        query = Goods.objects.filter(gtype = uid)
        
        # 如果有关键词，添加搜索条件
        if keyword:
            query = query.filter(goodname__contains=keyword)
        
        # 分页处理
        from django.core.paginator import Paginator
        page_size = 12  # 每页显示12个商品
        paginator = Paginator(query, page_size)
        
        # 获取当前页码
        page = request.GET.get('page', 1)
        
        # 获取当前页的商品列表
        ob = paginator.get_page(page)
        
        context = {
            "ob": ob,
            "keyword": keyword,
            "uid": uid
        }
    except Exception as err:
        print(err)
        context = {"info":"商品显示失败"}
    return render(request,"web/goods/list.html",context)

#显示购买商品页面
def shop(request,uid):
    try:
        ob = Goods.objects.get(id = uid)
        context = {"ob":ob}
    except Exception as err:
        print(err)
        context = {"info":"商品显示失败"}
    return render(request,"web/goods/shop.html",context)

#执行购买
def shopping(request,uid):
    try:
        ob = Goods.objects.get(id = uid)
        try:
            current_username = request.session['webuser']['username']
        except Exception:
            context = {"info":"请先登录", "ob": ob}
            return render(request,"web/goods/shop.html",context)
        user = User.objects.filter(username=current_username).first()
        of = Order()
        of.ordername = ob.goodname
        of.orderuser = user.username  # 使用正确的字段名orderuser
        # 移除image字段，因为Order模型没有此字段
        of.price = ob.price
        # 从POST请求中获取用户输入的地址
        of.address = request.POST.get('address', '待填写')
        of.confirm = "待确认"
        # 从POST请求中获取用户输入的购买数量，默认为1
        of.number = int(request.POST.get('number', 1))
        of.save()
        # 更新session中的购物车数量
        request.session['cart_count'] = Order.objects.filter(orderuser=user.username).count()
        context = {"info":"购买成功", "ob": ob}
    except Exception as err:
        print(err)
        # 确保即使出错也传递ob变量
        try:
            ob = Goods.objects.get(id = uid)
            context = {"info":"购买失败", "ob": ob}
        except:
            context = {"info":"购买失败，商品不存在"}
    return render(request,"web/goods/shop.html",context)

#显示购物记录
def orderlist(request):
    try:
        current_username = request.session['webuser']['username']
        ob = Order.objects.filter(orderuser=current_username)  # 使用正确的字段名orderuser
        # 更新session中的购物车数量
        request.session['cart_count'] = ob.count()
        info_msg = request.GET.get('info')
        context = {"ob":ob}
        if info_msg:
            context["info"] = info_msg
    except Exception as err:
        print(err)
        context = {"info":"购物记录显示失败"}
    return render(request,"web/goods/orderlist.html",context)

#确认收到货物
def confirm(request,uid):
    try:
        ob = Order.objects.get(id = uid)
        ob.confirm = 2
        ob.save()
        # 更新session中的购物车数量（可选：确认收货后可能需要更新数量）
        try:
            current_username = request.session['webuser']['username']
            request.session['cart_count'] = Order.objects.filter(orderuser=current_username).count()
        except:
            pass
        return redirect('/web/orderlist/?info=确认成功')
    except Exception as err:
        print(err)
        return redirect('/web/orderlist/?info=确认失败')
    
#显示收藏页面
def xfavorite(request):
    try:
        current_username = request.session['webuser']['username']
        ob = favorite.objects.filter(users__username=current_username)
        # 更新session中的收藏数量
        request.session['favorite_count'] = ob.count()
        info_msg = request.GET.get('info')
        context = {"ob": ob, "info": info_msg}
    except KeyError:
        context = {"info": "请先登录后查看收藏"}
    except Exception as err:
        print(err)
        context = {"info":"您还没收藏任何商品"}
    return render(request,"web/goods/favorite.html",context)

#执行收藏
def dofavorite(request, uid):
    try:
        goods = Goods.objects.get(id=uid)
        current_username = request.session['webuser']['username']
        user = User.objects.filter(username=current_username).first()
        if not user:
            return redirect(reverse('web_login'))
        # 防重复
        exists = favorite.objects.filter(
            favorite_name=goods.goodname,
            users__id=user.id
        ).exists()
        if exists:
            return redirect(f"{reverse('web_xfavorite')}?info=该商品已收藏")
        # 创建收藏记录
        of = favorite()
        of.favorite_image = goods.image
        of.favorite_name = goods.goodname
        try:
            of.favorite_price = int(goods.price)
        except Exception:
            of.favorite_price = 0
        of.save()
        # 关联用户
        of.users.add(user)
        # 更新session中的收藏数量
        request.session['favorite_count'] = favorite.objects.filter(users__id=user.id).count()
        return redirect(f"{reverse('web_xfavorite')}?info=收藏成功")
    except Goods.DoesNotExist:
        return redirect(f"{reverse('web_xfavorite')}?info=商品不存在")
    except KeyError:
        return redirect(f"{reverse('web_login')}?info=请先登录")
    except Exception as err:
        print(err)
        return redirect(f"{reverse('web_xfavorite')}?info=收藏失败")

#取消收藏
def dlefavorite(request, uid):
    try:
        ob = favorite.objects.get(id=uid)
        current_username = request.session['webuser']['username']
        user = User.objects.filter(username=current_username).first()
        if not user:
            context = {"info": "请先登录"}
            return render(request, "web/goods/favorite.html", context)
        if user in ob.users.all():
            ob.users.remove(user)
            info_msg = "取消收藏成功"
        else:
            info_msg = "你未收藏该内容"
        ob_list = favorite.objects.filter(users__id=user.id)
        # 更新session中的收藏数量
        request.session['favorite_count'] = ob_list.count()
        context = {"ob": ob_list, "info": info_msg}
        return render(request, "web/goods/favorite.html", context)
    except favorite.DoesNotExist:
        context = {"info": "收藏记录不存在"}
        return render(request, "web/goods/favorite.html", context)
    except KeyError:
        context = {"info": "未登录或会话失效"}
        return render(request, "web/goods/favorite.html", context)
    except Exception as err:
        print(f"取消收藏错误：{err}")
        context = {"info": "取消收藏失败"}
        return render(request, "web/goods/favorite.html", context)
#显示特惠商品
def preferential(request):
    try:
        ob =  Goods.objects.filter(price__isnull=False).order_by('price')[:5]
        context = {"ob":ob}
    except Exception as err:
        print(err)
        context = {"info":"没有特惠商品"}
    return render(request,"web/goods/preferential.html",context)
def newgoods(request):
    try:
        # 1. 获取最新的创建时间
        latest_time = Goods.objects.aggregate(max_time=Max('create_time'))['max_time']
        
        if latest_time:
            # 2. 筛选所有同时间的最新商品（列表类型）
            ob_list = Goods.objects.filter(create_time=latest_time)
            # 关键：变量名用ob_list，与模板接收的一致
            context = {"ob_list": ob_list}
        else:
            context = {"info": "最近没有新增的产品"}
    
    except Exception as err:
        print(err)  # 建议打印具体错误，方便调试（如数据库连接问题）
        context = {"info": "最近没有新增的产品"}
    
    return render(request, "web/goods/newgoods.html", context)