"""
URL configuration for shopweb project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
#from django.contrib import admin
from django.urls import path,include
from web.views import login,goods

urlpatterns = [
    #path('admin/', admin.site.urls),
    #用户登录
    path("",login.ulogin,name="web_login"),#显示登录页面
    path("dologin/",login.udologin,name="web_dologin"),#执行登录
    path("register/",login.uregister,name="web_register"),#显示注册页面
    path("doregister/",login.udoregister,name="web_doregister"),#执行注册
    path("web/",include([
        path("logout/",login.ulogout,name="web_logout"),#执行退出登录
        path("personal/",login.personal,name="web_personal"),#显示个人页面
        path("epersonal/<int:uid>/",login.epersonal,name="web_epersonal"),#执行编辑个人页面
        path("index/",login.index,name="web_index"),#显示首页
        #商品列表
        path("list/<int:uid>/",goods.list,name="web_list"),#显示商品列表
        path("shop/<int:uid>/",goods.shop,name="web_shop"),
        path("shopping/<int:uid>/",goods.shopping,name="web_shopping"),#执行购买
        path("orderlist/",goods.orderlist,name="web_orderlist"),#显示购物记录
        path("confirm/<int:uid>",goods.confirm,name="web_confirm"),#确认收到货物
        path("favorite/",goods.xfavorite,name="web_xfavorite"),#显示收藏页面
        path("dofavorite/<int:uid>",goods.dofavorite,name="web_dofavorite"),#执行收藏
        path("dlefavorite/<int:uid>",goods.dlefavorite,name="web_dlefavorite"),#取消收藏
        path("preferential/",goods.preferential,name="web_preferential"),#显示特惠界面
        path("newgoods/",goods.newgoods,name="web_newgoods"),#显示新增页面
    ]))
    
]
