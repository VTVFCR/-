from django.db import models
class User(models.Model):
    # 性别选择项
    GENDER_CHOICES = [
        ('M', '男'),
        ('F', '女'),
        ('O', '其他'),
    ]
    
    username = models.CharField(max_length=50, unique=True, verbose_name="用户名")
    password = models.CharField(max_length=128, verbose_name="密码")
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES, null=True, blank=True, verbose_name="性别")
    birthday = models.DateField(null=True, blank=True, verbose_name="出生日期")

    def toDict(self):
        return {"id":self.id,"username":self.username,"password":self.password,"gender":self.gender,"birthday": self.birthday.strftime("%Y-%m-%d %H:%M:%S")}

    class Meta:
        verbose_name = "用户"
        verbose_name_plural = "用户"
        db_table = "user"  #更换表名





class Goods(models.Model):
    # 商品种类选项
    GTYPE_CHOICES = [
        (1, "电子产品"),    
        (2, "服装鞋帽"),    
        (3, "家居生活"),    
        (4, "美妆护肤"),    
        (5, "图书文具"), 
    ]
    goodname = models.CharField(max_length=50, unique=True, verbose_name="商品名")
    # 价格字段：max_digits=10（总位数），decimal_places=2（保留2位小数）
    price = models.DecimalField(
        max_digits=10,    # 整数部分+小数部分的总位数（如 12345678.90 共10位）
        decimal_places=2, # 保留2位小数（符合货币规范）
        verbose_name="价格"
    )
    number = models.IntegerField(verbose_name="数量")
    gtype = models.IntegerField(choices=GTYPE_CHOICES, default=1, verbose_name="商品种类")

    # 新增图片字段
    image = models.ImageField(
        upload_to='goods_images/',  # 上传路径（会自动创建在MEDIA_ROOT下）
        null=True,                  # 允许为空（可选填）
        blank=True,                 # 表单提交时允许为空
        verbose_name="商品图片"
    )
    
    # 新增时间字段：创建时间（仅首次保存时自动设置）
    create_time = models.DateTimeField(
        auto_now_add=True,  # 新增记录时自动保存当前时间
        verbose_name="创建时间"
    )
    
    # 可选：更新时间（每次保存时自动更新为当前时间）
    update_time = models.DateTimeField(
        auto_now=True,  # 每次更新记录时自动更新为当前时间
        verbose_name="更新时间"
    )
    
    def toDict(self):
        # 注意：图片需要返回URL而非原始路径，时间需要格式化
        return {
            "id": self.id,
            "goodname": self.goodname,
            "price": self.price,
            "number": self.number,
            "gtype": self.get_gtype_display(),  # 返回中文类型名
            "image_url": self.image.url if self.image else "",  # 图片URL
            "create_time": self.create_time.strftime("%Y-%m-%d %H:%M:%S"),  # 格式化创建时间
            "update_time": self.update_time.strftime("%Y-%m-%d %H:%M:%S")   # 格式化更新时间
        }
    
    class Meta:
        verbose_name = "商品"
        verbose_name_plural = "商品"
        db_table = "goods"  # 更换表名

class Admin(models.Model):
    GENDER_CHOICES = [
        ('M', '男'),
        ('F', '女'),
        ('O', '其他'),
    ]
    adminname = models.CharField(max_length=50, unique = True,verbose_name="管理员姓名")
    password = models.CharField(max_length=128, verbose_name="密码")
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES, null=True, blank=True, verbose_name="性别")

    def toDict(self):
        return {"id":self.id,"adminname":self.adminname,"password":self.password,"gender":self.gender}
    class Meta:
        verbose_name="管理员"
        verbose_name_plural = "管理员"
        db_table = "admin"#更换表名




    #显示账单
class Order(models.Model):
    orderuser = models.CharField(max_length=50,unique=False,verbose_name="用户账号")
    ordername = models.CharField(max_length=50,unique=False,verbose_name="商品名称")
    number = models.IntegerField(verbose_name="购买数量")
    address = models.CharField(max_length=50,verbose_name="地址")
    confirm = models.CharField(max_length=50,verbose_name="消息")
    price = models.DecimalField(
        max_digits=10,    # 整数部分+小数部分的总位数（如 12345678.90 共10位）
        decimal_places=2, # 保留2位小数（符合货币规范）
        verbose_name="价格"
    )

    def toDict(self):
        return {"id":self.id,"ordername":self.ordername,"number":self.number,"address":self.address,"price":self.price,"confirm":self.confirm}
    class Meta:
        verbose_name="订单"
        verbose_name_plural="订单"
        db_table = "order"#更换表名

class favorite(models.Model):
    favorite_name=models.CharField(max_length=50,unique=False,verbose_name="收藏商品")
    favorite_price = models.IntegerField(verbose_name="价格")
    favorite_image = models.ImageField(
        upload_to='goods_images/',  # 上传路径（会自动创建在MEDIA_ROOT下）
        null=True,                  # 允许为空（可选填）
        blank=True,                 # 表单提交时允许为空
        verbose_name="商品图片"
    )
    users = models.ManyToManyField(
        User,  # 关联你的自定义User模型
        related_name="favorites",  # 反向查询别名：通过用户查他的收藏（user.favorites.all()）
        verbose_name="关联用户"
    )
    def toDict(self):
         # 多对多字段需要通过 .all() 查询，转换为用户信息列表
        user_list = [{"id": u.id, "username": u.username} for u in self.users.all()]
        return {"id":self.id,
                "favorite_name":self.favorite_name,
                "favorite_price":self.favorite_price,
                "image_url": self.image.url if self.image else "" , # 图片URL
                "users": user_list  # 关联的用户列表
    }
    class Meta:
        verbose_name="收藏"
        verbose_name_plural="收藏"
        db_table = "favorite"#更换表名
