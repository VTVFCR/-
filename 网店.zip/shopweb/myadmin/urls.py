"""
URL configuration for shopweb project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
#from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from myadmin.views import good
from myadmin.views import user
from myadmin.views import login
urlpatterns = [
    #path('admin/', admin.site.urls),
    #商品操作
    #path("index/",good.index,name="good_index"),#显示商品页面
    #path("add/",good.add,name="good_add"),#显示添加页面
   # path("insert/",good.insert,name="good_insert"),#执行添加
   # path("delete/<int:uid>/",good.delete,name="good_delete"),#执行删除
   # path("edit/<int:uid>/",good.editgood,name="good_edit"),#显示编辑页面
    #path("update/<int:uid>/",good.update,name="good_update"),#执行编辑
    #用户操作
    path("uindex/",user.index,name="user_index"),#显示用户页面
    path("uadd/",user.add,name="user_add"),#显示添加页面
    path("uinsert/",user.insert,name="user_insert"),#执行添加
    path("udelete/<int:uid>/",user.delete,name="user_delete"),#执行删除
    path("uedit/<int:uid>/",user.edituser,name="user_edit"),#显示编辑页面
    path("uupdate/<int:uid>/",user.update,name="user_update"),#执行编辑
    #管理员登录
    path("login/",login.alogin,name="myadmin_login"),#显示登录页面
    path("dologin/",login.adologin,name="myadmin_dologin"),#执行登录
    path("register/",login.aregister,name="myadmin_register"),#显示注册页面
    path("doregister/",login.adoregister,name="myadmin_doregister"),#执行注册
    path("logout/",login.alogout,name="myadmin_logout"),#执行推出的登录
    path("editp/",login.editp,name="myadmin_editp"),#显示更改密码页面
    path("personal/",login.personal,name="myadmin_personal"),#显示个人信息页面
    path("updatep/<int:uid>/",login.updatep,name="updatep"),#编辑个人信息
    #商品
    path("list/<int:uid>/",good.index,name="good_list"),#显示商品页面
    path("add/",good.add,name="good_add"),#显示添加页面
    path("insert/",good.insert,name="good_insert"),#执行添加
    path("delete/<int:uid>/",good.delete,name="good_delete"),#执行删除
    path("edit/<int:uid>/",good.editgood,name="good_edit"),#显示编辑页面
    path("update/<int:uid>/",good.update,name="good_update"),#执行编辑
    #首页
    path("index/",login.index,name="myadmin_index"),#显示首页
    path("orderlist/",good.orderlist,name="myadmin_orderlist"),#显示账单

]
