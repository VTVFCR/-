from django.shortcuts import render
from django.http import HttpResponse
from myadmin.models import Goods,Order
#显示商品信息
def index(request,uid):
    try:
        # 获取搜索关键词
        keyword = request.GET.get('keyword', '').strip()
        
        # 基础查询 - 按类型筛选
        query = Goods.objects.filter(gtype=uid)
        
        # 如果有关键词，添加搜索条件
        if keyword:
            query = query.filter(goodname__contains=keyword)
        
        # 分页处理
        from django.core.paginator import Paginator
        page_size = 10  # 每页显示10个商品
        paginator = Paginator(query, page_size)
        
        # 获取当前页码
        page = request.GET.get('page', 1)
        
        # 获取当前页的商品列表
        goodlist = paginator.get_page(page)
        
        context = {
            "goodlist": goodlist,
            "keyword": keyword,
            "uid": uid
        }
    except Exception as err:
        print(err)
        context = {"goodlist": Goods.objects.none(), "keyword": "", "uid": uid}
    return render(request,"myadmin/goods/goods.html",context)
#显示添加页面
def add(request):
    return render(request,"myadmin/goods/add.html")
#执行添加
def insert(request):
    try:
        ob = Goods()
        ob.goodname = request.POST.get("goodname")
        ob.price = request.POST.get("price")
        ob.number = request.POST.get("number")
        
        # 处理商品类型
        gtype = request.POST.get("gtype")
        if gtype == "电子产品":
            ob.gtype = 1
        elif gtype == "服装鞋帽":
            ob.gtype = 2  
        elif gtype == "家居生活":
            ob.gtype = 3   
        elif gtype == "美妆护肤":
            ob.gtype = 4  
        elif gtype == "图书文具":
            ob.gtype = 5       
            
        # 新增：处理图片上传（从request.FILES获取）
        if 'image' in request.FILES:  # 判断是否有上传图片
            ob.image = request.FILES['image']  # 保存图片到模型的image字段
            
        ob.save()
        content = {"info":"添加成功"}
    except Exception as err:
        print(err)
        content = {"info":"添加失败"}
    return render(request,"myadmin/goods/info.html",content)
#执行删除
def delete(request,uid=0):
    try:

        ob = Goods.objects.get(id = uid)
        ob.delete()
        content = {"info":"删除成功"}
    except Exception as err:
        print(err)
        content = {"info":"删除失败"}
    return render(request,"myadmin/goods/info.html",content)
#显示编辑页面
def editgood(request,uid=0):
    try:
  
        ob = Goods.objects.get(id=uid)
        content = {"ob":ob}
        return render(request,"myadmin/goods/edit.html",content)
    except Exception as err:
        print(err)
        content = {"info":"获取不到信息"}
        return render(request,"myadmin/goods/info.html",content)
#进行编辑
def update(request, uid):
    try:
        ob = Goods.objects.get(id=uid)
        
        # 更新基本信息
        ob.goodname = request.POST.get('goodname')  
        ob.price = request.POST.get('price')
        ob.number = request.POST.get('number')
        
        # 更新商品类型
        gtype = request.POST.get("gtype")
        if gtype == "电子产品":
            ob.gtype = 1
        elif gtype == "服装鞋帽":
            ob.gtype = 2  
        elif gtype == "家居生活":
            ob.gtype = 3   
        elif gtype == "美妆护肤":
            ob.gtype = 4  
        elif gtype == "图书文具":
            ob.gtype = 5     
        
     
        if 'image' in request.FILES:
            # 如果有旧图片，可选择删除（避免服务器存储冗余）
            import os
            from django.conf import settings
            if ob.image and os.path.exists(os.path.join(settings.MEDIA_ROOT, str(ob.image))):
                os.remove(os.path.join(settings.MEDIA_ROOT, str(ob.image)))
            
            # 保存新图片
            ob.image = request.FILES['image']
        
        ob.save()
        content = {"info": "编辑成功"}  
    except Exception as err:
        print(err)
        content = {"info": "编辑失败"}  
    return render(request, "myadmin/goods/info.html", content)
#显示账单列表
def orderlist(request):
    try:
        ob = Order.objects.all()
        context = {"ob":ob}
        return render(request,"myadmin/goods/orderlist.html",context)
    except Exception as err:
        print(err)
        context = {"info":"显示失败"}
        return render(request,"myadmin/goods/orderlist.html",context)





