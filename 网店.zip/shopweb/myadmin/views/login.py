from django.shortcuts import redirect, render
from django.urls import reverse
from myadmin.models import Admin
# Create your views here.
#显示登录页面
def alogin(request):
    try:
        return render(request,"myadmin/login/login.html")
    except Exception as err:
        print(err)
#进行登录
def adologin(request):
    try:
        user = Admin.objects.get(adminname = request.POST.get('adminuser'))
        p = request.POST.get("password")
        if user.password == p:
            print("登录成功")
            #将当前成功登陆的用户以adminuser为key写入到session中去
            request.session["adminuser"] = user.toDict()
            #重定向到后台首页
            return redirect(reverse('myadmin_index'))
        else:
             # 密码错误时，给 context 赋值
            context = {"info": "密码错误，请重新输入"}

    except Exception as err:
        print(err)
        context = {"info":"该账号不存在"}
    return render(request,"myadmin/login/login.html",context)
#显示注册页面
def aregister(request):
    return render(request,"myadmin/login/register.html")
#进行注册
def adoregister(request):
    try:
        ob = Admin()
        ob.adminname = request.POST.get("adminname")
        ob.password = request.POST.get("password")
        ob.gender = request.POST.get("gender")
        ob.save()
        context = {"info":"注册成功"}
    except Exception as err:
        print(err)
        context = {"info":"注册失败"}
    return render(request,"myadmin/login/info.html",context)
#执行退出登录
def alogout(request):
    del request.session['adminuser']
    return redirect(reverse('myadmin_login'))
#显示密码修改页面
def editp(request):
    return render(request,"myadmin/login/updatep.html")
#显示当前登录者的信息
def personal(request):    
    if "adminuser" in request.session:
        try:
            current_adminname = request.session['adminuser']['adminname']
            ob = Admin.objects.filter(adminname = current_adminname).first()
            context = {"ob":ob}
            return render(request,"myadmin/login/personal.html",context)
        except Exception as err:
            print(err)
            return render(request,"myadmin/login/login.html")
#进行编辑
def updatep(request,uid=0):
    try:
        ob = Admin.objects.get(id = uid)
        ob.adminname = request.POST.get("adminname")
        gender = request.POST.get("gender")
        if gender=="男":
            ob.gender = 'M'
        elif gender == "女":
            ob.gender = 'F'
        else:
            ob.gender = None
        ob.save()
        context = {"info":"编辑成功"}
    except Exception as err:
        print(err)
        context = {"info":"编辑失败"}
    return render(request,"myadmin/login/info.html",context)
#显示首页
def index(request):
    try:
        return render(request,"myadmin/index.html")
    except Exception as err:
        print(err)

    
    

