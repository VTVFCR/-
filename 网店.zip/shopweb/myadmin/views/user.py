from django.shortcuts import render
from myadmin.models import User
# Create your views here.
#显示用户页面
def index(request):
    try:
        # 获取搜索关键词
        keyword = request.GET.get('keyword', '').strip()
        
        # 基础查询
        query = User.objects.all()
        
        # 如果有关键词，添加搜索条件
        if keyword:
            query = query.filter(username__contains=keyword)
        
        # 分页处理
        from django.core.paginator import Paginator
        page_size = 10  # 每页显示10个用户
        paginator = Paginator(query, page_size)
        
        # 获取当前页码
        page = request.GET.get('page', 1)
        
        # 获取当前页的用户列表
        ulist = paginator.get_page(page)
        
        context = {
            "ulist": ulist,
            "keyword": keyword
        }
    except Exception as err:
        print(err)
        context = {"ulist": User.objects.none(), "keyword": ""}
    return render(request,"myadmin/user/ulist.html",context)
#显示添加页面
def add(request):
    return render(request,"myadmin/user/add.html")
#执行添加
def insert(request):
    try:
        ob = User()
        ob.username = request.POST.get("username")
        ob.password = request.POST.get("password")
        gender = request.POST.get("gender")  # 假设表单中性别字段名为"gender"
        if gender == "男":
            ob.gender = "M"
        elif gender == "女":
            ob.gender = "F"
        else:
            # 处理未选择或其他情况，可根据需求设置默认值或留空
            ob.gender = None  # 或设置为默认值如""
        ob.birthday = request.POST.get("birthday")
        ob.save()
        context = {"info":"添加成功"}
    except Exception as err:
        print(err)
        context = {"info":"添加失败"}
    return render(request,"myadmin/user/info.html",context)
#执行删除
def delete(request,uid=0):
    try:
        ob = User.objects.get(id = uid)
        ob.delete()
        content={"info":"删除成功"}
    except Exception as err:
        print(err)
        content = {"info":"删除失败"}
    return render(request,"myadmin/user/info.html",content)
#显示编辑页面
def edituser(request,uid=0):
    try:
        ob = User.objects.get(id = uid)
        content = {"ob":ob}
        return render(request,"myadmin/user/edit.html",content)
    except Exception as err:
        print(err)
        content = {"info":"无法获取信息"}
        return render(request,"myadmin/user/info.html",content)
#执行编辑
def update(request,uid=0):
    try:
        ob =User.objects.get(id = uid)
        ob.username = request.POST.get("username")
        ob.password = request.POST.get("password")
        gender = request.POST.get("gender")
        if gender=="男":
            ob.gender = 'M'
        elif gender == "女":
            ob.gender = 'F'
        else:
            ob.gender = None
        ob.save()
        content = {"info":"编辑成功"}

    except Exception as err:
        print(err)
        content = {"info":"编辑失败"}
    return render(request,"myadmin/user/info.html",content)