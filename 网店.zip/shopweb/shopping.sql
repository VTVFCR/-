/*
SQLyog Ultimate v12.08 (64 bit)
MySQL - 8.0.43 : Database - shopping
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`shopping` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `shopping`;

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `adminname` varchar(50) NOT NULL,
  `password` varchar(128) NOT NULL,
  `gender` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `adminname` (`adminname`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `admin` */

insert  into `admin`(`id`,`adminname`,`password`,`gender`) values (1,'wang','123456','F'),(2,'laoliu','abcdef','M'),(3,'laoq','147258','M'),(6,'aa','852963','M');

/*Table structure for table `auth_group` */

DROP TABLE IF EXISTS `auth_group`;

CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `auth_group` */

/*Table structure for table `auth_group_permissions` */

DROP TABLE IF EXISTS `auth_group_permissions`;

CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `auth_group_permissions` */

/*Table structure for table `auth_permission` */

DROP TABLE IF EXISTS `auth_permission`;

CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `auth_permission` */

insert  into `auth_permission`(`id`,`name`,`content_type_id`,`codename`) values (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add 商品',7,'add_goods'),(26,'Can change 商品',7,'change_goods'),(27,'Can delete 商品',7,'delete_goods'),(28,'Can view 商品',7,'view_goods'),(29,'Can add 用户',8,'add_user'),(30,'Can change 用户',8,'change_user'),(31,'Can delete 用户',8,'delete_user'),(32,'Can view 用户',8,'view_user'),(33,'Can add 管理员',9,'add_admin'),(34,'Can change 管理员',9,'change_admin'),(35,'Can delete 管理员',9,'delete_admin'),(36,'Can view 管理员',9,'view_admin'),(37,'Can add 订单',10,'add_order'),(38,'Can change 订单',10,'change_order'),(39,'Can delete 订单',10,'delete_order'),(40,'Can view 订单',10,'view_order'),(41,'Can add 用户收藏',11,'add_favorite'),(42,'Can change 用户收藏',11,'change_favorite'),(43,'Can delete 用户收藏',11,'delete_favorite'),(44,'Can view 用户收藏',11,'view_favorite');

/*Table structure for table `auth_user` */

DROP TABLE IF EXISTS `auth_user`;

CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `auth_user` */

/*Table structure for table `auth_user_groups` */

DROP TABLE IF EXISTS `auth_user_groups`;

CREATE TABLE `auth_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `auth_user_groups` */

/*Table structure for table `auth_user_user_permissions` */

DROP TABLE IF EXISTS `auth_user_user_permissions`;

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `auth_user_user_permissions` */

/*Table structure for table `django_admin_log` */

DROP TABLE IF EXISTS `django_admin_log`;

CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `django_admin_log` */

/*Table structure for table `django_content_type` */

DROP TABLE IF EXISTS `django_content_type`;

CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `django_content_type` */

insert  into `django_content_type`(`id`,`app_label`,`model`) values (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(9,'myadmin','admin'),(11,'myadmin','favorite'),(7,'myadmin','goods'),(10,'myadmin','order'),(8,'myadmin','user'),(6,'sessions','session');

/*Table structure for table `django_migrations` */

DROP TABLE IF EXISTS `django_migrations`;

CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `django_migrations` */

insert  into `django_migrations`(`id`,`app`,`name`,`applied`) values (1,'contenttypes','0001_initial','2025-09-20 12:39:11.582166'),(2,'auth','0001_initial','2025-09-20 12:39:12.109143'),(3,'admin','0001_initial','2025-09-20 12:39:12.312497'),(4,'admin','0002_logentry_remove_auto_add','2025-09-20 12:39:12.319501'),(5,'admin','0003_logentry_add_action_flag_choices','2025-09-20 12:39:12.331455'),(6,'contenttypes','0002_remove_content_type_name','2025-09-20 12:39:12.439511'),(7,'auth','0002_alter_permission_name_max_length','2025-09-20 12:39:12.505917'),(8,'auth','0003_alter_user_email_max_length','2025-09-20 12:39:12.530203'),(9,'auth','0004_alter_user_username_opts','2025-09-20 12:39:12.538138'),(10,'auth','0005_alter_user_last_login_null','2025-09-20 12:39:12.601625'),(11,'auth','0006_require_contenttypes_0002','2025-09-20 12:39:12.610118'),(12,'auth','0007_alter_validators_add_error_messages','2025-09-20 12:39:12.620382'),(13,'auth','0008_alter_user_username_max_length','2025-09-20 12:39:12.696056'),(14,'auth','0009_alter_user_last_name_max_length','2025-09-20 12:39:12.754972'),(15,'auth','0010_alter_group_name_max_length','2025-09-20 12:39:12.773281'),(16,'auth','0011_update_proxy_permissions','2025-09-20 12:39:12.781542'),(17,'auth','0012_alter_user_first_name_max_length','2025-09-20 12:39:12.837027'),(18,'myadmin','0001_initial','2025-09-20 12:39:12.892358'),(19,'sessions','0001_initial','2025-09-20 12:39:12.928114'),(20,'myadmin','0002_admin','2025-10-16 07:26:41.920433'),(21,'myadmin','0003_order','2025-10-16 08:29:54.254082'),(22,'myadmin','0004_goods_gtype','2025-10-16 08:58:42.786004'),(23,'myadmin','0005_auto_20251022_1702','2025-10-22 09:03:06.876122'),(24,'myadmin','0006_order_price','2025-10-22 12:19:22.036711'),(25,'myadmin','0007_alter_order_ordername','2025-10-23 13:40:34.998526'),(26,'myadmin','0008_auto_20251024_1338','2025-10-24 05:38:39.769172'),(27,'myadmin','0009_order_confirm','2025-10-24 08:28:50.958643'),(28,'myadmin','0010_goods_favorite','2025-10-28 02:22:35.528435'),(29,'myadmin','0011_auto_20251028_1522','2025-10-28 07:22:12.997533'),(30,'myadmin','0012_auto_20251028_1539','2025-10-28 07:39:42.281511'),(31,'myadmin','0013_remove_goods_favorite','2025-10-28 12:15:34.299489'),(32,'myadmin','0014_favorite','2025-10-28 12:34:04.321659'),(33,'myadmin','0015_auto_20251030_2121','2025-10-30 13:21:16.846170');

/*Table structure for table `django_session` */

DROP TABLE IF EXISTS `django_session`;

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `django_session` */

insert  into `django_session`(`session_key`,`session_data`,`expire_date`) values ('blgyu5gjxj9hs3irqqfx9mfrlizz5fah','.eJwdi0sKgCAURbcSd1zwtM_APbSIJ0o2yEKLqHDvvYIzOZdzH5zeHtknmAezg1E1Po28eBjcgeOUOaLGxjmfa5IESrddP8g2-ei-K0YRO6c9OL5ENRE1pISKyPyglBdGHR-t:1vDyo3:dw7hA__Cut5C_mWvRvAMTB-chzwFRfxrasmAgu6dPrg','2025-11-12 05:33:11.051456'),('ogpsmf5wlqr3lwi1x8k43xz99mcmwkku','.eJyFjk0OwiAUhK9iZo3Jo_4sOIA7z2BeC7YsCgZoiTbcXdroxo3JbL7JTPItyKadoglQC6yGkgIrOh4NFF4Duz6yg8CDY8w-1AlkcziezrXrjdPrFdcKrQ1p0Pys2BDRnmTNjkhtQRG48-yDTebW-cklqEag45C-KEmA9Wjdj8_WfYRy9fknc0EpbzpHQhg:1vFqyy:OoVosLMUeCKeMcd0nK7pfzF1TfWDE3cbIH8iCr-hBLo','2025-11-17 09:36:12.362134');

/*Table structure for table `favorite` */

DROP TABLE IF EXISTS `favorite`;

CREATE TABLE `favorite` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `favorite_name` varchar(50) NOT NULL,
  `favorite_price` int NOT NULL,
  `favorite_image` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `favorite` */

insert  into `favorite`(`id`,`favorite_name`,`favorite_price`,`favorite_image`) values (1,'sss',999,'goods_images/Warmaster.jpg.webp'),(2,'sss',999,'goods_images/Warmaster.jpg.webp'),(3,'as',50,''),(4,'sd',50,''),(5,'df',60,''),(6,'sd',50,''),(7,'sss',999,'goods_images/Warmaster.jpg.webp'),(8,'sss',999,'goods_images/Warmaster.jpg.webp');

/*Table structure for table `favorite_users` */

DROP TABLE IF EXISTS `favorite_users`;

CREATE TABLE `favorite_users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `favorite_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `favorite_users_favorite_id_user_id_dcd651d8_uniq` (`favorite_id`,`user_id`),
  KEY `favorite_users_user_id_b7210cce_fk_user_id` (`user_id`),
  CONSTRAINT `favorite_users_favorite_id_57e86f2f_fk_favorite_id` FOREIGN KEY (`favorite_id`) REFERENCES `favorite` (`id`),
  CONSTRAINT `favorite_users_user_id_b7210cce_fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `favorite_users` */

insert  into `favorite_users`(`id`,`favorite_id`,`user_id`) values (3,6,1),(5,8,1);

/*Table structure for table `goods` */

DROP TABLE IF EXISTS `goods`;

CREATE TABLE `goods` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `goodname` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `number` int NOT NULL,
  `gtype` int NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `create_time` datetime(6) NOT NULL,
  `update_time` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `goodname` (`goodname`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `goods` */

insert  into `goods`(`id`,`goodname`,`price`,`number`,`gtype`,`image`,`create_time`,`update_time`) values (1,'lll','50.00',60,2,NULL,'2025-10-30 13:21:16.801950','2025-10-30 13:21:16.830430'),(5,'sds','900.00',50,3,NULL,'2025-10-30 13:21:16.801950','2025-10-30 13:21:16.830430'),(6,'fg','60.00',60,4,NULL,'2025-10-30 13:21:16.801950','2025-10-30 13:21:16.830430'),(7,'dfg','90.00',60,5,NULL,'2025-10-30 13:21:16.801950','2025-10-30 13:21:16.830430'),(11,'sss','999.00',878,1,'goods_images/Warmaster.jpg.webp','2025-10-30 13:21:16.801950','2025-10-30 13:21:16.830430'),(12,'555','5555.00',555,5,NULL,'2025-10-30 13:21:16.801950','2025-10-30 13:21:16.830430'),(14,'444','4444.00',4444,4,NULL,'2025-10-15 13:21:16.000000','2025-10-30 13:21:16.830430'),(15,'as','50.00',50,1,NULL,'2025-10-07 13:21:16.000000','2025-10-30 13:21:16.830430'),(16,'sd','50.00',50,1,NULL,'2025-10-15 13:21:16.000000','2025-10-30 13:21:16.830430'),(17,'df','60.00',60,1,NULL,'2025-10-24 13:21:16.000000','2025-10-30 13:21:16.830430'),(18,'9','60.00',60,1,NULL,'2025-10-30 13:21:16.801950','2025-10-30 13:21:16.830430'),(19,'gh','60.00',60,1,NULL,'2025-10-24 13:21:16.000000','2025-10-30 13:21:16.830430'),(20,'hj','60.00',60,1,NULL,'2025-10-22 13:21:16.000000','2025-10-30 13:21:16.830430'),(22,'we','60.00',60,1,'goods_images/codm_2025_02_01_20_31_23.png','2025-10-30 13:21:16.801950','2025-10-30 13:21:16.830430'),(23,'kkkk','50.00',9000,2,'goods_images/v2-6ef6ef69155c937cfe84eb0982e1657c_720w.jpg','2025-11-03 09:37:03.187840','2025-11-03 09:37:03.187840');

/*Table structure for table `order` */

DROP TABLE IF EXISTS `order`;

CREATE TABLE `order` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `ordername` varchar(50) NOT NULL,
  `number` int NOT NULL,
  `address` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `orderuser` varchar(50) NOT NULL,
  `confirm` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `order` */

insert  into `order`(`id`,`ordername`,`number`,`address`,`price`,`orderuser`,`confirm`) values (1,'sss',1,'ss','999.00','llls',''),(4,'sss',1,'shanghai','999.00','llls','yes'),(5,'sss',1,'lslsls','999.00','','yes'),(6,'sss',1,'dsds','999.00','zhangsan','YES'),(7,'sss',1,'ddd','999.00','zhangsan','yes'),(8,'sss',1,'ddd','999.00','zhangsan','yes'),(9,'sss',1,'上海','999.00','zhangsan','YES'),(10,'sss',3,'上海','999.00','zhangsan','已收货'),(11,'sss',1,'待填写','999.00','zhangsan','2'),(12,'sss',1,'待填写','999.00','zhangsan','2'),(13,'sss',1,'待填写','999.00','zhangsan','2'),(14,'as',1,'待填写','50.00','zhangsan','待确认'),(15,'sss',1,'上海','999.00','zhangsan','待确认');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(128) NOT NULL,
  `gender` varchar(6) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `user` */

insert  into `user`(`id`,`username`,`password`,`gender`,`birthday`) values (1,'zhangsan','123456','M','2000-01-01'),(5,'sss','123456','M','2025-10-08'),(7,'ddd','555','M','2025-10-02'),(8,'sdsds','123456',NULL,'2025-10-21');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
